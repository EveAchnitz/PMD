import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart'; // Import necessário para Lottie

void main() {
  runApp(AnimalQuizApp());
}

class AnimalQuizApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Que animal você seria?',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.purple,
        scaffoldBackgroundColor: Color(0xffefd0f4),
        textTheme: TextTheme(
          headlineSmall: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          bodyLarge: TextStyle(fontSize: 18),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            padding: EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            elevation: 4,
          ),
        ),
      ),
      home: StartScreen(),
    );
  }
}

// === StartScreen: tela inicial ===
class StartScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Descubra seu animal interior')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                '🐾 Pronto para descobrir qual animal combina com você?',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              SizedBox(height: 40),
              ElevatedButton.icon(
                icon: Icon(Icons.play_circle_fill),
                label: Text('Começar o Quiz'),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => QuizScreen()),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// === QuizScreen: perguntas ===
class QuizScreen extends StatefulWidget {
  @override
  _QuizScreenState createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int _questionIndex = 0;
  Map<String, int> _scores = {
    'Leão': 0,
    'Coruja': 0,
    'Golfinho': 0,
    'Urso': 0,
    'Tartaruga': 0,
    'Arara': 0,
  };

  final _questions = [
    {
      'question': 'O que você prefere fazer no tempo livre?',
      'answers': {
        'Explorar e liderar': 'Leão',
        'Ler ou estudar': 'Coruja',
        'Conversar e brincar': 'Golfinho',
        'Descansar e relaxar': 'Urso',
        'Fazer atividades manuais (tricotar, desenhar, etc)': 'Tartaruga',
        'Passear ou fazer atividades ao ar livre': 'Arara',
      }
    },
    {
      'question': 'Como você se descreveria?',
      'answers': {
        'Corajoso(a) e determinado(a)': 'Leão',
        'Inteligente e observador(a)': 'Coruja',
        'Alegre e sociável': 'Golfinho',
        'Calmo(a) e confiável': 'Urso',
        'Tranquilo(a) e conselheiro(a)': 'Tartagura',
        'Extrovertido(a) e amigável': 'Arara',
      }
    },
    {
      'question': 'Qual ambiente você prefere?',
      'answers': {
        'Selva ou floresta': 'Leão',
        'Lugar tranquilo para pensar': 'Coruja',
        'Praia ou mar': 'Golfinho',
        'Cabana nas montanhas': 'Urso',
        'Minha casinha': 'Tartaruga',
        'Bosque ou parque': 'Arara',
      }
    },
    {
      'question': 'Para ser seu amigo, precisa ser:',
      'answers': {
        'Confiável': 'Leão',
        'Honesto(a)': 'Coruja',
        'Gentil': 'Golfinho',
        'Calmo(a)': 'Urso',
        'Parceiro(a)': 'Tartaruga',
        'Engraçado(a)': 'Arara',
      }
    },
    {
      'question': 'Qual tipo de filme você mais gosta de assistir?',
      'answers': {
        'Ação e aventura': 'Leão',
        'Ficção científica e suspense': 'Coruja',
        'Comédia e romance': 'Golfinho',
        'Aventura e animação': 'Urso',
        'Documentário e drama': 'Tartaruga',
        'Aventura e comédia': 'Arara',
      }
    },
    {
      'question': 'Como você age diante um trabalho em equipe?',
      'answers': {
        'Tomo a liderança e mantenho tudo em ordem': 'Leão',
        'Planejo e organizo tudo': 'Coruja',
        'Penso em algumas ideias para ajudar': 'Golfinho',
        'Escuto a todos e fico disponível para ajudar': 'Urso',
        'Observo e dou minha opinião, se necessário': 'Tartaruga',
        'Compartilho minhas ideias e opiniões': 'Arara',
      }
    },
    {
      'question': 'Qual é o seu maior medo?',
      'answers': {
        'Não obter sucesso ou não ser reconhecido por algo que fiz': 'Leão',
        'Fracassar': 'Coruja',
        'Ser abandonado ou rejeitado': 'Golfinho',
        'Ser subestimado': 'Urso',
        'Ser exposta': 'Tartaruga',
        'Ser uma pessoa solitária': 'Arara',
      }
    },
    {
      'question': 'Quais são as suas maiores priporidades?',
      'answers': {
        'Meu trabalho e bens': 'Leão',
        'Meu estudo e minha saúde mental': 'Coruja',
        'Meus amigos e minha espiritualide': 'Golfinho',
        'Minha saúde e família': 'Urso',
        'Minha espiritualidade e família': 'Tartaruga',
        'Meus amigos e minha família': 'Arara',
      }
    },
    {
      'question': 'Qual passeio mais combina com você?',
      'answers': {
        'Shopping': 'Leão',
        'Livraria ou cafeteria': 'Coruja',
        'Karaokê': 'Golfinho',
        'Cinema': 'Urso',
        'Restaurante': 'Tartaruga',
        'Festas e shows': 'Arara',
      }
    },
    {
      'question': 'Qual tipo de presente você gosta de receber?',
      'answers': {
        'Dinheiro, roupa e acessórios': 'Leão',
        'Livros e jogos': 'Coruja',
        'Viagens': 'Golfinho',
        'Cartinhas feitas a mão': 'Urso',
        'Materiais artísticos': 'Tartaruga',
        'Doces e guloseimas': 'Arara',
      }
    }
  ];

  void _answerQuestion(String animal) {
    setState(() {
      _scores[animal] = _scores[animal]! + 1;
      _questionIndex++;
    });
    if (_questionIndex >= _questions.length) {
      final result =
          _scores.entries.reduce((a, b) => a.value > b.value ? a : b).key;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => ResultScreen(animal: result)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final current = _questions[_questionIndex];
    return Scaffold(
      appBar: AppBar(
          title: Text('Pergunta ${_questionIndex + 1}/${_questions.length}')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(current['question'] as String,
                style: Theme.of(context).textTheme.headlineSmall),
            SizedBox(height: 20),
            ...((current['answers'] as Map<String, String>).entries.map(
                  (e) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    child: ElevatedButton(
                      onPressed: () => _answerQuestion(e.value),
                      child: Text(e.key),
                    ),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}

// === ResultScreen: resultado com animação Lottie ===
class ResultScreen extends StatelessWidget {
  final String animal;
  ResultScreen({required this.animal});

  // Mapeamento: animal -> descrição e link Lottie
  final _data = {
    'Leão': {
      'desc': '🦁 Você é líder, corajoso(a) e determinado(a)!',
      'lottie':
          'https://lottie.host/af3421a0-cd2c-4d26-922f-2e3b11a94748/gIoZBh6gEK.json',
    },
    'Coruja': {
      'desc': '🦉 Você é sábio(a), observador(a) e ama aprender!',
      'lottie':
          'https://lottie.host/f3c4385f-46df-4c46-b6a0-22c5d18c0ef7/CmqRrlrRu3.json',
    },
    'Golfinho': {
      'desc': '🐬 Você é alegre, comunicativo(a) e divertido(a)!',
      'lottie':
          'https://lottie.host/1e70b90f-f1ff-4443-87c3-409cb07a5876/ExyNkVem4q.json',
    },
    'Urso': {
      'desc': '🐻 Você é tranquilo(a), acolhedor(a) e confiável!',
      'lottie':
          'https://lottie.host/fd80125b-ec8f-43ee-a71d-289f5cbf9a87/wcW9OBVObS.json',
    },
    'Tartaruga': {
      'desc': '🐢 Você é calmo(a) e delicado(a).',
      'lottie':
          'https://lottie.host/3f519cd4-1832-4cf7-90ac-8a97edccaafb/lDXGcrKbfZ.json',
    },
    'Arara': {
      'desc': '🦜 Você é divertido(a) e extrovertido(a)!',
      'lottie':
          'https://lottie.host/31f42bcc-a9d4-46d5-8faa-ad8461da65fd/EvJoaPLkGs.json'
    },
  };

  @override
  Widget build(BuildContext context) {
    final info = _data[animal]!;
    return Scaffold(
      appBar: AppBar(title: Text('Seu animal interior')),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(32.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Exibe animação Lottie
              Lottie.network(info['lottie']!, height: 200),
              SizedBox(height: 24),
              Text(
                'Você seria um(a) $animal!',
                style: Theme.of(context).textTheme.headlineSmall,
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 16),
              Text(
                info['desc']!,
                style: Theme.of(context).textTheme.bodyLarge,
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 40),
              ElevatedButton.icon(
                icon: Icon(Icons.restart_alt),
                label: Text('Refazer o Quiz'),
                onPressed: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (_) => StartScreen()),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
